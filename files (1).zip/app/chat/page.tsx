'use client';

import { useState, useRef, useEffect } from 'react';
import styles from './chat.module.css';

interface Message {
  user: string;
  ai: string;
  timestamp: string;
}

export default function ChatPage() {
  const [msg, setMsg] = useState('');
  const [chat, setChat] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chat]);

  const send = async () => {
    if (!msg.trim()) {
      setError('Please enter a message');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: msg,
          userId: 'demo-user',
        }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(
          errorData.error || `Server error: ${res.status} ${res.statusText}`
        );
      }

      const data = await res.json();

      if (!data.reply) {
        throw new Error('No response received from AI');
      }

      const timestamp = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      });

      setChat([
        ...chat,
        {
          user: msg,
          ai: data.reply,
          timestamp,
        },
      ]);
      setMsg('');
      setIsConnected(true);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : 'An unexpected error occurred';
      setError(errorMessage);
      setIsConnected(false);
      console.error('Chat error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2>💙 SootheAI Chat</h2>
        <p className={styles.subtitle}>
          Your AI Emotional Support Companion
        </p>
        <div
          className={`${styles.connectionStatus} ${
            isConnected ? styles.connected : styles.disconnected
          }`}
        >
          <span className={styles.dot}></span>
          {isConnected ? 'Connected' : 'Connection issues'}
        </div>
      </div>

      <div className={styles.messagesContainer}>
        {chat.length === 0 && (
          <div className={styles.emptyState}>
            <h3>👋 Welcome to SootheAI</h3>
            <p>
              I&apos;m here to listen and support you. Feel free to share
              anything on your mind.
            </p>
          </div>
        )}

        {chat.map((c, i) => (
          <div key={i} className={styles.messageGroup}>
            <div className={`${styles.message} ${styles.userMessage}`}>
              <div className={styles.messageContent}>
                <p>{c.user}</p>
                <span className={styles.time}>{c.timestamp}</span>
              </div>
            </div>
            <div className={`${styles.message} ${styles.aiMessage}`}>
              <div className={styles.messageContent}>
                <p>{c.ai}</p>
                <span className={styles.time}>{c.timestamp}</span>
              </div>
            </div>
          </div>
        ))}

        {loading && (
          <div className={`${styles.message} ${styles.aiMessage}`}>
            <div className={styles.messageContent}>
              <div className={styles.loadingDots}>
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {error && (
        <div className={styles.errorBanner}>
          <span>⚠️ {error}</span>
          <button
            className={styles.closeError}
            onClick={() => setError(null)}
          >
            ✕
          </button>
        </div>
      )}

      <div className={styles.inputContainer}>
        <input
          type="text"
          value={msg}
          onChange={(e) => setMsg(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Type your message here..."
          disabled={loading}
          className={styles.input}
        />
        <button
          onClick={send}
          disabled={loading || !msg.trim()}
          className={styles.sendButton}
        >
          {loading ? '...' : '➤ Send'}
        </button>
      </div>
    </div>
  );
}