import { openai } from '@/lib/openai';
import { supabase } from '@/lib/supabaseClient';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    // Validate request body
    let body;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      );
    }

    const { message, userId } = body;

    // Validate required fields
    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Message is required and must be a string' },
        { status: 400 }
      );
    }

    if (!userId || typeof userId !== 'string') {
      return NextResponse.json(
        { error: 'UserId is required and must be a string' },
        { status: 400 }
      );
    }

    // Trim and validate message length
    const trimmedMessage = message.trim();
    if (trimmedMessage.length === 0) {
      return NextResponse.json(
        { error: 'Message cannot be empty' },
        { status: 400 }
      );
    }

    if (trimmedMessage.length > 5000) {
      return NextResponse.json(
        { error: 'Message is too long (max 5000 characters)' },
        { status: 400 }
      );
    }

    // Call OpenAI API
    let response;
    try {
      response = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content:
              'You are a calm, supportive emotional wellness assistant. Provide empathetic, helpful responses while encouraging the user to seek professional help for serious mental health concerns. Keep responses concise but meaningful.',
          },
          {
            role: 'user',
            content: trimmedMessage,
          },
        ],
        max_tokens: 500,
        temperature: 0.7,
      });
    } catch (openaiError: unknown) {
      console.error('OpenAI API Error:', openaiError);

      if (openaiError instanceof Error) {
        if (openaiError.message.includes('rate_limit')) {
          return NextResponse.json(
            {
              error: 'Too many requests. Please wait a moment and try again.',
            },
            { status: 429 }
          );
        }
        if (openaiError.message.includes('authentication')) {
          return NextResponse.json(
            { error: 'Authentication error. Please try again later.' },
            { status: 401 }
          );
        }
      }

      return NextResponse.json(
        { error: 'Failed to get response from AI service' },
        { status: 503 }
      );
    }

    // Validate response
    if (!response.choices || response.choices.length === 0) {
      return NextResponse.json(
        { error: 'No response from AI service' },
        { status: 500 }
      );
    }

    const reply = response.choices[0].message?.content;
    if (!reply) {
      return NextResponse.json(
        { error: 'Empty response from AI service' },
        { status: 500 }
      );
    }

    // Store in database
    try {
      const { error: insertError } = await supabase.from('chats').insert([
        {
          user_id: userId,
          message: trimmedMessage,
          response: reply,
          created_at: new Date().toISOString(),
        },
      ]);

      if (insertError) {
        console.error('Database insertion error:', insertError);
        // Don't fail the request if database insert fails - return the AI response anyway
        console.warn(
          'Chat history not saved, but returning AI response to user'
        );
      }
    } catch (dbError) {
      console.error('Database error:', dbError);
      // Continue - we still want to return the AI response
    }

    return NextResponse.json({ reply }, { status: 200 });
  } catch (error) {
    console.error('Unexpected error in chat API:', error);
    return NextResponse.json(
      {
        error:
          'An unexpected error occurred. Please try again later or contact support.',
      },
      { status: 500 }
    );
  }
}