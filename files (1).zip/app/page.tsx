'use client';

import { useRouter } from 'next/navigation';
import styles from './page.module.css';

export default function Home() {
  const router = useRouter();

  const handleStartChat = () => {
    router.push('/chat');
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <div className={styles.hero}>
          <h1 className={styles.title}>💙 SootheAI</h1>
          <p className={styles.tagline}>Your AI Emotional Support Companion</p>
          <p className={styles.description}>
            Welcome to a safe space where you can share your thoughts and
            feelings. SootheAI is here to listen, understand, and provide
            compassionate support whenever you need it.
          </p>
        </div>

        <div className={styles.features}>
          <div className={styles.feature}>
            <span className={styles.featureIcon}>🤝</span>
            <h3>Always Available</h3>
            <p>Chat anytime, anywhere. No appointments needed.</p>
          </div>

          <div className={styles.feature}>
            <span className={styles.featureIcon}>🔒</span>
            <h3>Private & Secure</h3>
            <p>Your conversations are confidential and encrypted.</p>
          </div>

          <div className={styles.feature}>
            <span className={styles.featureIcon}>💬</span>
            <h3>Supportive</h3>
            <p>Empathetic responses tailored to your needs.</p>
          </div>
        </div>

        <button className={styles.ctaButton} onClick={handleStartChat}>
          ✨ Start Chat Now
        </button>

        <p className={styles.disclaimer}>
          ⚠️ <strong>Note:</strong> SootheAI is not a substitute for
          professional mental health treatment. If you&apos;re experiencing a
          crisis, please contact a mental health professional or emergency
          services.
        </p>
      </div>
    </div>
  );
}