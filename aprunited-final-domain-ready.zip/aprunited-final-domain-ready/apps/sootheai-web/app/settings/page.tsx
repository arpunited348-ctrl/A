export default function SettingsPage() {
  return (
    <main className="max-w-2xl">
      <h1 className="mb-6 text-3xl font-semibold">Settings</h1>
      <div className="card p-6">
        <p className="text-slate-300">Add profile editing, notifications, and privacy preferences here.</p>
      </div>
    </main>
  );
}
