export default function LoginPage() {
  return (
    <main className="mx-auto max-w-md">
      <div className="card p-6">
        <h1 className="mb-2 text-2xl font-semibold">Login</h1>
        <p className="mb-6 text-sm text-slate-400">Connect this page to Supabase auth.</p>
        <form className="space-y-4">
          <input className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3" placeholder="Email" />
          <input className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3" placeholder="Password" type="password" />
          <button className="w-full rounded-xl bg-white px-4 py-3 font-medium text-slate-900" type="button">Login</button>
        </form>
      </div>
    </main>
  );
}
