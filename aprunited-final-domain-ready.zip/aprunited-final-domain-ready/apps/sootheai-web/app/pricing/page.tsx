const tiers = [
  { name: "Free", price: "₹0", desc: "Explore SootheAI with limited chats.", features: ["Starter chat access", "Basic dashboard", "Simple history"] },
  { name: "Pro", price: "₹199/mo", desc: "For consistent personal support.", features: ["More chat sessions", "Priority responses", "Saved conversations"] },
  { name: "Premium", price: "₹499/mo", desc: "For deeper guided usage.", features: ["Unlimited core chat", "Advanced mood insights", "Priority features"] },
];

export default function PricingPage() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-16">
      <div className="mb-12 text-center">
        <p className="mb-3 text-sm uppercase tracking-[0.25em] text-sky-300">Pricing</p>
        <h1 className="text-4xl font-semibold text-white sm:text-5xl">Simple plans for calm, clarity, and growth.</h1>
        <p className="mx-auto mt-4 max-w-2xl text-slate-300">Start free and upgrade when you want deeper support and higher usage limits.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {tiers.map((tier) => (
          <section key={tier.name} className="card p-6">
            <h2 className="text-2xl font-semibold text-white">{tier.name}</h2>
            <p className="mt-2 text-3xl font-bold text-white">{tier.price}</p>
            <p className="mt-3 text-slate-300">{tier.desc}</p>
            <ul className="mt-6 space-y-2 text-sm text-slate-300">
              {tier.features.map((feature) => <li key={feature}>• {feature}</li>)}
            </ul>
            <button className="mt-8 w-full rounded-xl bg-white px-4 py-3 font-medium text-slate-900">Choose {tier.name}</button>
          </section>
        ))}
      </div>
    </main>
  );
}
