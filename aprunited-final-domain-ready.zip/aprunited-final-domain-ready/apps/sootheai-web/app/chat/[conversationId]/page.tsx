export default async function ConversationPage({ params }: { params: Promise<{ conversationId: string }> }) {
  const { conversationId } = await params;
  return (
    <main>
      <h1 className="mb-2 text-3xl font-semibold">Conversation</h1>
      <p className="text-slate-400">Load conversation <span className="font-mono">{conversationId}</span> from Supabase here.</p>
    </main>
  );
}
