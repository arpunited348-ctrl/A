import { ChatBox } from '@/components/ChatBox';

export default function ChatPage() {
  return (
    <main>
      <h1 className="mb-6 text-3xl font-semibold">Chat</h1>
      <ChatBox />
    </main>
  );
}
