import Link from "next/link";
import { NavBar } from "@/components/NavBar";

export default function HomePage() {
  return (
    <main>
      <NavBar />
      <section className="grid gap-8 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="mb-3 text-sm uppercase tracking-[0.25em] text-sky-300">APR United Product</p>
          <h1 className="mb-5 text-5xl font-semibold leading-tight text-white sm:text-6xl">Your calm AI companion for emotional clarity.</h1>
          <p className="mb-8 max-w-2xl text-lg text-slate-300">
            SootheAI helps people process stress, overthinking, and emotional overload in a private, supportive, always-on space.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="/signup" className="rounded-xl bg-white px-5 py-3 font-medium text-slate-900">Start Free</Link>
            <Link href="/pricing" className="rounded-xl border border-slate-700 px-5 py-3 text-white">See Pricing</Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <div className="rounded-2xl bg-slate-950 p-4"><p className="text-2xl font-semibold text-white">24/7</p><p className="text-sm text-slate-400">always available</p></div>
            <div className="rounded-2xl bg-slate-950 p-4"><p className="text-2xl font-semibold text-white">Private</p><p className="text-sm text-slate-400">judgment-free support</p></div>
            <div className="rounded-2xl bg-slate-950 p-4"><p className="text-2xl font-semibold text-white">Guided</p><p className="text-sm text-slate-400">supportive reflections</p></div>
          </div>
        </div>
        <div className="card p-6">
          <div className="space-y-4">
            <div className="rounded-2xl bg-slate-950 p-4 text-sm text-slate-200">“I’m feeling overwhelmed and can’t focus.”</div>
            <div className="rounded-2xl bg-sky-950/60 p-4 text-sm text-sky-100">“Let’s slow it down together. What feels most urgent right now?”</div>
            <div className="rounded-2xl border border-slate-800 p-4">
              <p className="text-sm uppercase tracking-[0.2em] text-slate-400">Built for</p>
              <p className="mt-2 text-white">Daily emotional support, guided reflection, and gentle AI-first wellness experiences.</p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
