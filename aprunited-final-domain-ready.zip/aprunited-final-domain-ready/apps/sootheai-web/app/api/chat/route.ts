import { NextResponse } from 'next/server';
import { openai } from '@/lib/openai';

export async function POST(request: Request) {
  try {
    const { message } = await request.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Invalid message' }, { status: 400 });
    }

    const response = await openai.chat.completions.create({
      model: 'gpt-4.1-mini',
      messages: [
        {
          role: 'system',
          content:
            'You are SootheAI, a calm and supportive emotional wellness assistant. Be empathetic, non-judgmental, practical, and warm. Do not claim to be a licensed therapist. If the user appears in immediate danger or self-harm crisis, urge them to seek local emergency or professional support immediately.'
        },
        {
          role: 'user',
          content: message
        }
      ]
    });

    return NextResponse.json({ reply: response.choices[0]?.message?.content ?? 'I am here with you.' });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Failed to get AI response' }, { status: 500 });
  }
}
