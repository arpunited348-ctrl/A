export default function DashboardPage() {
  return (
    <main>
      <h1 className="mb-6 text-3xl font-semibold">Dashboard</h1>
      <div className="grid gap-4 md:grid-cols-3">
        <div className="card p-5"><p className="text-sm text-slate-400">Sessions this week</p><p className="mt-2 text-3xl font-semibold">5</p></div>
        <div className="card p-5"><p className="text-sm text-slate-400">Mood trend</p><p className="mt-2 text-3xl font-semibold">Improving</p></div>
        <div className="card p-5"><p className="text-sm text-slate-400">Plan</p><p className="mt-2 text-3xl font-semibold">Free</p></div>
      </div>
    </main>
  );
}
