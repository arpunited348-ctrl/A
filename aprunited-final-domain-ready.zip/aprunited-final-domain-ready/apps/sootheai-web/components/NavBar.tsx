import Link from 'next/link';

export function NavBar() {
  return (
    <header className="mb-8 flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-900/70 px-5 py-4">
      <Link href="/" className="text-lg font-semibold">SootheAI</Link>
      <nav className="flex gap-4 text-sm text-slate-300">
        <Link href="/pricing">Pricing</Link>
        <Link href="/login">Login</Link>
        <Link href="/signup">Signup</Link>
      </nav>
    </header>
  );
}
