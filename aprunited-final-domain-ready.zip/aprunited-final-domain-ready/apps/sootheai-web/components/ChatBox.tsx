'use client';

import { useState } from 'react';

type Message = { role: 'user' | 'assistant'; content: string };

export function ChatBox() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  async function sendMessage() {
    if (!input.trim() || loading) return;
    const current = input;
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', content: current }]);
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: current })
      });

      const data = await response.json();
      setMessages((prev) => [...prev, { role: 'assistant', content: data.reply ?? 'No reply received.' }]);
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Something went wrong. Please try again.' }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card p-4">
      <div className="mb-4 h-[420px] space-y-3 overflow-y-auto rounded-xl bg-slate-950 p-4">
        {messages.length === 0 && <p className="text-sm text-slate-400">Start a calm conversation ✨</p>}
        {messages.map((message, index) => (
          <div key={index} className={message.role === 'user' ? 'text-right' : 'text-left'}>
            <span className="inline-block max-w-[85%] rounded-2xl bg-slate-800 px-4 py-2 text-sm">
              {message.content}
            </span>
          </div>
        ))}
      </div>
      <div className="flex gap-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="What’s on your mind?"
          className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 outline-none"
        />
        <button
          onClick={sendMessage}
          className="rounded-xl bg-white px-5 py-3 font-medium text-slate-900 disabled:opacity-60"
          disabled={loading}
        >
          {loading ? 'Sending…' : 'Send'}
        </button>
      </div>
    </div>
  );
}
