import Link from "next/link";
import { Nav } from "@/components/Nav";

const ventures = [
  { name: "SootheAI", tag: "Mental wellness AI", href: "https://sootheai.aprunited.io" },
  { name: "APR United", tag: "Parent startup studio", href: "/about" },
];

export default function HomePage() {
  return (
    <main>
      <Nav />
      <section className="grid gap-10 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="mb-3 text-sm uppercase tracking-[0.25em] text-sky-700">APR United</p>
          <h1 className="mb-5 text-5xl font-semibold leading-tight text-slate-950 sm:text-6xl">
            Building digital startups with bold vision and real execution.
          </h1>
          <p className="mb-8 max-w-2xl text-lg text-slate-600">
            APR United is a startup studio focused on product-led brands in AI, automation, and digital experiences.
            We launch focused products, validate demand, and turn ideas into scalable ventures.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="/startups" className="rounded-2xl bg-slate-950 px-5 py-3 font-medium text-white">Explore Ventures</Link>
            <Link href="/founders" className="rounded-2xl border border-slate-300 px-5 py-3 text-slate-800">Meet the Team</Link>
          </div>
        </div>
        <div className="card p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="rounded-2xl bg-slate-50 p-5"><p className="text-sm text-slate-500">Studio Model</p><p className="mt-2 text-2xl font-semibold">Build • Validate • Scale</p></div>
            <div className="rounded-2xl bg-slate-50 p-5"><p className="text-sm text-slate-500">Core Focus</p><p className="mt-2 text-2xl font-semibold">AI + SaaS</p></div>
            <div className="rounded-2xl bg-slate-50 p-5"><p className="text-sm text-slate-500">Flagship</p><p className="mt-2 text-2xl font-semibold">SootheAI</p></div>
            <div className="rounded-2xl bg-slate-50 p-5"><p className="text-sm text-slate-500">Goal</p><p className="mt-2 text-2xl font-semibold">Fundable Products</p></div>
          </div>
          <div className="mt-6 space-y-3">
            {ventures.map((venture) => (
              <div key={venture.name} className="flex items-center justify-between rounded-2xl border border-slate-200 p-4">
                <div>
                  <p className="font-semibold text-slate-950">{venture.name}</p>
                  <p className="text-sm text-slate-500">{venture.tag}</p>
                </div>
                <Link href={venture.href} className="text-sm font-medium text-sky-700">View</Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
