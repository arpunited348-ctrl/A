const startups = [
  { name: 'SootheAI', desc: 'AI-first emotional support platform focused on daily mental clarity.', href: 'https://sootheai.aprunited.io' },
  { name: 'More to come', desc: 'Future APR United ventures can be added here.', href: '#' }
];

export default function StartupsPage() {
  return (
    <main>
      <h1 className="mb-8 text-4xl font-semibold">Startups</h1>
      <div className="grid gap-4 md:grid-cols-2">
        {startups.map((startup) => (
          <div key={startup.name} className="card p-6">
            <h2 className="text-2xl font-semibold">{startup.name}</h2>
            <p className="mt-2 text-slate-600">{startup.desc}</p>
            <a href={startup.href} className="mt-4 inline-block text-sky-700">Visit →</a>
          </div>
        ))}
      </div>
    </main>
  );
}
