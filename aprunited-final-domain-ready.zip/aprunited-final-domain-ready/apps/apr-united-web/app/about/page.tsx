export default function AboutPage() {
  return (
    <main className="max-w-3xl">
      <h1 className="mb-4 text-4xl font-semibold">About APR United</h1>
      <p className="text-lg text-slate-600">APR United builds products at the intersection of AI, usability, and commercial execution.</p>
    </main>
  );
}
