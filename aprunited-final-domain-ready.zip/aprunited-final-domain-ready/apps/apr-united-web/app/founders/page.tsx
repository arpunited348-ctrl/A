const founders = [
  { name: 'Prashant Thakur', role: 'CEO' },
  { name: 'Ankit Singh', role: 'MD' },
  { name: 'Raj Patwa', role: 'Vice President' }
];

export default function FoundersPage() {
  return (
    <main>
      <h1 className="mb-8 text-4xl font-semibold">Founders</h1>
      <div className="grid gap-4 md:grid-cols-3">
        {founders.map((founder) => (
          <div key={founder.name} className="card p-6">
            <h2 className="text-xl font-semibold">{founder.name}</h2>
            <p className="mt-2 text-slate-600">{founder.role}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
