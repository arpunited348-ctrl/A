export default function TermsPage() {
  return <main><h1 className="text-4xl font-semibold">Terms of Service</h1><p className="mt-4 text-slate-600">Add your terms here.</p></main>;
}
