export default function ContactPage() {
  return (
    <main className="max-w-2xl">
      <h1 className="mb-4 text-4xl font-semibold">Contact</h1>
      <p className="text-slate-600">Replace this with your real contact form, email, and investor inquiry details.</p>
    </main>
  );
}
