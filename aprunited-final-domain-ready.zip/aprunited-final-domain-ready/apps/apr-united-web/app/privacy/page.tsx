export default function PrivacyPage() {
  return <main><h1 className="text-4xl font-semibold">Privacy Policy</h1><p className="mt-4 text-slate-600">Add your privacy policy here.</p></main>;
}
