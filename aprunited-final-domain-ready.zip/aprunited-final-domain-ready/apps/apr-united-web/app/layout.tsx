import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'APR United',
  description: 'APR United builds and launches digital products.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">{children}</div>
      </body>
    </html>
  );
}
